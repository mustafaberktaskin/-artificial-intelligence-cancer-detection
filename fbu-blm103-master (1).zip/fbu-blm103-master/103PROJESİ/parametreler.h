#ifndef parametreler_h
#define parametreler_h

#define N 5
#define PARAMETRE_SAYI 9

#define EGITIM_VERI_SAYI 600
#define EGITIM_DOSYA "egitim.txt"

#define TEST_VERI_SAYI 83
#define TEST_DOSYA "test.txt"

#endif /* parametreler_h */

